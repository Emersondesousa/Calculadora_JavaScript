let compras = [];

while (true){
    let opcao = Number(prompt("Informe a opção desejada: \n1:Adicionar item\n 2:Excluir item\n 3:Ver itens\n 4:Sair "));
    if (opcao == 1){
        let item = prompt("Informe o nome do item: ");
        if (item == ""){
            alert("Digite algo..")}
        else{
            compras.push(item);
            alert("Item adicionado com sucesso!");
        }}
    else if (opcao == 2){
        let posicao = Number(prompt("Informe a posição do item: "));
            if (posicao in compras){
                compras.splice(posicao, 1);
                alert("Item excluido com sucesso!");
            }
            else{
                alert("Item não encontrado.")
            }
        }
    else if (opcao == 3){
            alert(compras.join('\n'));
    } else if (opcao == 4){
        alert('Programa finalizado.')
        break
    }else{
        alert("Informe uma opção válida.")
    }
}
